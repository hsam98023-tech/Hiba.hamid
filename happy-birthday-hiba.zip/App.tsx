
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import FloatingHearts from './components/FloatingHearts';
import Typewriter from './components/Typewriter';
import RelationshipTimer from './components/RelationshipTimer';
import WhatsAppBox from './components/WhatsAppBox';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showBirthdayContent, setShowBirthdayContent] = useState(false);
  const [candlesBlown, setCandlesBlown] = useState(false);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(-1);
  
  // Real Birthday Date: April 4, 2026
  const targetDate = new Date('2026-04-04T00:00:00').getTime();
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0, isPast: false });

  // Update Countdown Timer
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true });
        setShowBirthdayContent(true);
        clearInterval(interval);
      } else {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
          isPast: false,
        });
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'hiba' && password === 'hamid') {
      setIsLoggedIn(true);
      setLoginError('');
    } else {
      setLoginError('بيانات الدخول غير صحيحة');
    }
  };

  const blowCandles = () => {
    setCandlesBlown(true);
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#ff69b4', '#ff1493', '#da70d6']
    });
    setTimeout(() => {
      setCurrentMessageIndex(0);
    }, 1500);
  };

  const birthdayMessages = [
    "🎉 عيد ميلاد سعيد يا هبة 🎉\nلقد أتممتِ الآن عامك الـ 17 بكل جمال ورقة!",
    "عيد ميلادك ليس مجرد يوم، بل هو اليوم الذي وُلدت فيه سعادتي، وكل عام وأنتِ نبضي الذي لا يهدأ 💗",
    "في يوم ميلادك، لا أحتفل فقط بعامٍ جديد من عمرك، بل أحتفل بوجودك في حياتي، بضحكتك التي تُنير أيامي، وبقلبك الذي علّمني معنى الحب الحقيقي. كل لحظة معك هي هدية، وكل يوم بجانبك هو نعمة أحمد الله عليها. أتمنى لك سعادة لا تنتهي، وراحة تسكن قلبك، ونجاحًا يرافق خطواتك أينما ذهبتِ. أعدك أن أكون معك في الفرح قبل الحزن، وفي القوة قبل الضعف، وأن أبقى سندًا لك ما دامت الأيام تجمعنا. كل عام وأنتِ أقرب إلى قلبي، وأجمل في عيني، وأغلى ما أملك. دمتِ لي حياةً، ودام حبّنا نورًا لا ينطفئ، وبقيتُ معك ما بقي العمر 🤍✨"
  ];

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-300 to-pink-200 flex flex-col items-center justify-center p-4">
        <FloatingHearts />
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white/80 backdrop-blur-lg rounded-3xl p-8 shadow-2xl w-full max-sm:w-full max-w-sm border border-white/50 relative z-10"
        >
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-pink-600 cursive">Welcome Hiba 💗</h1>
            <p className="text-pink-400 mt-2">من فضلكِ قومي بتسجيل الدخول</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <input 
                type="text" 
                placeholder="اسم المستخدم"
                className="w-full p-3 rounded-xl border border-pink-200 focus:ring-2 focus:ring-pink-400 outline-none bg-white/50 text-right"
                value={username}
                onChange={(e) => setUsername(e.target.value.toLowerCase())}
              />
            </div>
            <div>
              <input 
                type="password" 
                placeholder="كلمة المرور"
                className="w-full p-3 rounded-xl border border-pink-200 focus:ring-2 focus:ring-pink-400 outline-none bg-white/50 text-right"
                value={password}
                onChange={(e) => setPassword(e.target.value.toLowerCase())}
              />
            </div>
            {loginError && <p className="text-red-500 text-sm text-center">{loginError}</p>}
            <button 
              type="submit"
              className="w-full bg-pink-500 hover:bg-pink-600 text-white font-bold py-3 rounded-xl transition-all shadow-lg active:scale-95"
            >
              دخول
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-300 via-purple-200 to-pink-100 flex flex-col items-center pt-10 pb-20 px-6 relative overflow-x-hidden">
      <FloatingHearts />
      
      <div className="w-full max-w-2xl flex flex-col items-center z-10">
        <AnimatePresence mode="wait">
          {!showBirthdayContent ? (
            <motion.div 
              key="countdown"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="text-center"
            >
              <h2 className="text-2xl text-pink-700 font-bold mb-8">العد التنازلي ليوم ميلادكِ السعيد (4-4-2026)...</h2>
              <div className="grid grid-cols-4 gap-4 mb-10">
                {[
                  { val: timeLeft.days, label: 'يوم' },
                  { val: timeLeft.hours, label: 'ساعة' },
                  { val: timeLeft.minutes, label: 'دقيقة' },
                  { val: timeLeft.seconds, label: 'ثانية' }
                ].map((item, idx) => (
                  <div key={idx} className="bg-white/50 backdrop-blur rounded-2xl p-4 shadow-md border border-pink-200 flex flex-col items-center w-16 sm:w-24">
                    <span className="text-xl sm:text-3xl font-bold text-pink-600">{item.val}</span>
                    <span className="text-xs sm:text-sm text-pink-400">{item.label}</span>
                  </div>
                ))}
              </div>
              <div className="mt-10 p-8 rounded-full bg-pink-200/50 animate-heartbeat text-5xl">💗</div>
            </motion.div>
          ) : (
            <motion.div 
              key="birthday"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center w-full"
            >
              {/* Birthday Surprise Content */}
              <div className="relative mb-12">
                <svg viewBox="0 0 200 200" className="w-48 h-48 sm:w-64 sm:h-64">
                  <rect x="40" y="100" width="120" height="60" rx="10" fill="#fbcfe8" />
                  <rect x="50" y="70" width="100" height="40" rx="10" fill="#f9a8d4" />
                  {!candlesBlown && (
                    <>
                      <rect x="75" y="45" width="4" height="25" fill="#f472b6" />
                      <path d="M77 35 Q80 40 77 45 Q74 40 77 35" fill="#facc15" className="animate-pulse" />
                      <rect x="121" y="45" width="4" height="25" fill="#f472b6" />
                      <path d="M123 35 Q126 40 123 45 Q120 40 123 35" fill="#facc15" className="animate-pulse" />
                      <rect x="98" y="40" width="4" height="30" fill="#f472b6" />
                      <path d="M100 25 Q103 35 100 40 Q97 35 100 25" fill="#facc15" className="animate-pulse" />
                    </>
                  )}
                  {candlesBlown && (
                    <motion.g initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                      <circle cx="77" cy="40" r="3" fill="#cbd5e1" opacity="0.5" />
                      <circle cx="100" cy="35" r="3" fill="#cbd5e1" opacity="0.5" />
                      <circle cx="123" cy="40" r="3" fill="#cbd5e1" opacity="0.5" />
                    </motion.g>
                  )}
                </svg>
                
                {!candlesBlown && (
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={blowCandles}
                    className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-white text-pink-600 font-bold py-2 px-6 rounded-full shadow-lg border-2 border-pink-300 whitespace-nowrap"
                  >
                    إطفاء الشموع 🎂
                  </motion.button>
                )}
              </div>

              <div className="w-full text-center space-y-6 min-h-[200px]">
                {currentMessageIndex >= 0 && (
                  <Typewriter 
                    text={birthdayMessages[0]} 
                    speed={60} 
                    className="text-2xl font-bold text-pink-700 whitespace-pre-line leading-relaxed"
                    onComplete={() => setTimeout(() => setCurrentMessageIndex(1), 2000)}
                  />
                )}
                {currentMessageIndex >= 1 && (
                  <Typewriter 
                    text={birthdayMessages[1]} 
                    speed={50} 
                    className="text-xl text-purple-600 italic mt-6 border-t border-pink-200 pt-6"
                    onComplete={() => setTimeout(() => setCurrentMessageIndex(2), 2000)}
                  />
                )}
                {currentMessageIndex >= 2 && (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }} 
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <Typewriter 
                      text={birthdayMessages[2]} 
                      speed={40} 
                      className="text-lg text-gray-700 mt-6 leading-loose text-justify p-4 bg-white/30 rounded-2xl"
                    />
                    <RelationshipTimer />
                    <WhatsAppBox />
                  </motion.div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <footer className="mt-12 text-pink-400 text-sm cursive">
          Made with Love for Hiba ❤️
        </footer>
      </div>
    </div>
  );
};

export default App;
