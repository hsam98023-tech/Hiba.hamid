
import React, { useState } from 'react';

const WhatsAppBox: React.FC = () => {
  const [message, setMessage] = useState('');
  const phoneNumber = '212644332264';

  const handleSend = () => {
    if (!message.trim()) return;
    const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="bg-white/60 backdrop-blur-md rounded-2xl p-6 shadow-lg border border-pink-100 mt-10 w-full max-w-md">
      <h3 className="text-lg font-bold text-pink-600 mb-4 text-center">أرسلي لي رسالة 💌</h3>
      <div className="flex flex-col gap-3">
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="اكتبي رسالتك هنا..."
          className="w-full p-3 rounded-xl border border-pink-200 focus:outline-none focus:ring-2 focus:ring-pink-400 bg-pink-50/50 resize-none h-24"
        />
        <button
          onClick={handleSend}
          className="bg-pink-500 hover:bg-pink-600 text-white font-bold py-3 rounded-xl transition-all shadow-md active:scale-95"
        >
          إرسال
        </button>
      </div>
    </div>
  );
};

export default WhatsAppBox;
