
import React, { useState, useEffect } from 'react';

const RelationshipTimer: React.FC = () => {
  const startDate = new Date('2024-07-15T00:00:00').getTime();
  const [timeSince, setTimeSince] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const difference = now - startDate;

      setTimeSince({
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((difference % (1000 * 60)) / 1000),
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [startDate]);

  return (
    <div className="bg-white/40 backdrop-blur-md rounded-2xl p-6 text-center border border-pink-200 shadow-xl mt-8">
      <h3 className="text-xl font-bold text-pink-600 mb-4">الوقت الذي قضيناه معاً 💗</h3>
      <div className="grid grid-cols-4 gap-2 text-pink-700">
        <div className="flex flex-col">
          <span className="text-2xl font-bold">{timeSince.days}</span>
          <span className="text-xs">يوم</span>
        </div>
        <div className="flex flex-col">
          <span className="text-2xl font-bold">{timeSince.hours}</span>
          <span className="text-xs">ساعة</span>
        </div>
        <div className="flex flex-col">
          <span className="text-2xl font-bold">{timeSince.minutes}</span>
          <span className="text-xs">دقيقة</span>
        </div>
        <div className="flex flex-col">
          <span className="text-2xl font-bold">{timeSince.seconds}</span>
          <span className="text-xs">ثانية</span>
        </div>
      </div>
      <p className="mt-4 text-sm italic text-purple-600">
        منذ تلك اللحظة الجميلة في 15 يوليو 2024، وحياتي أصبحت أجمل بكِ.
      </p>
    </div>
  );
};

export default RelationshipTimer;
